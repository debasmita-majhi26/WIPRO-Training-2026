def before_scenario(context, scenario):
    print(f"\nStarting Scenario: {scenario.name}")


def after_scenario(context, scenario):
    print(f"Finished Scenario: {scenario.name}")