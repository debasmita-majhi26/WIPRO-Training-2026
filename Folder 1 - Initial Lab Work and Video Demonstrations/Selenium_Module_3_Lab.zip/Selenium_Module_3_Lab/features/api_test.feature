Feature: API Automation

  @api
  Scenario: Verify GET API response

    Given I send a GET request to the posts API
    When I receive the API response
    Then the response status code should be 200