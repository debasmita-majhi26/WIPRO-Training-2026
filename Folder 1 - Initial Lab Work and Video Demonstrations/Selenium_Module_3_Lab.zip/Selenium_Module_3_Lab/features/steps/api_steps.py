import requests
from behave import given, when, then


@given("I send a GET request to the posts API")
def step_send_request(context):
    context.response = requests.get(
        "https://jsonplaceholder.typicode.com/posts/1"
    )


@when("I receive the API response")
def step_receive_response(context):
    context.status_code = context.response.status_code


@then("the response status code should be 200")
def step_verify_status(context):
    assert context.status_code == 200